document.addEventListener('DOMContentLoaded', function() {
    // عرض معلومات المستخدم من Local Storage
    document.getElementById('username').value = localStorage.getItem('username') || '';
    document.getElementById('age').value = localStorage.getItem('age') || '';
    document.getElementById('familySize').value = localStorage.getItem('familySize') || '';

    // معالجة عملية البحث
    document.getElementById('search-form').addEventListener('submit', function(e) {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const age = document.getElementById('age').value;
        const familySize = document.getElementById('familySize').value;
        const destination = document.getElementById('destination').value;
        const transport = document.getElementById('transport').value;

        // حفظ البيانات في Local Storage
        localStorage.setItem('username', username);
        localStorage.setItem('age', age);
        localStorage.setItem('familySize', familySize);
        localStorage.setItem('destination', destination);
        localStorage.setItem('transport', transport);

        // الانتقال إلى صفحة النتائج
        window.location.href = 'results.html';
    });
});
